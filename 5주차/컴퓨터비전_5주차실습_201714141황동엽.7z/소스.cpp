﻿#include <algorithm>
#include "moravec.hpp"
#include "opencv2/opencv.hpp"

transformations::Moravec::Moravec(cv::InputArray& original_image)
{
	cv::Mat src = original_image.getMat();
	confidence_map.create(src.size(), CV_32FC1);

	for (int w = 0; w < src.cols; ++w)
	{
		confidence_map.at<float>(0, w) = 0.0;
		confidence_map.at<float>(1, w) = 0.0;
		confidence_map.at<float>(src.rows - 1, w) = 0.0;
		confidence_map.at<float>(src.rows - 2, w) = 0.0;
	}

	for (int h = 0; h < src.rows; ++h)
	{
		confidence_map.at<float>(h, 0) = 0.0;
		confidence_map.at<float>(h, 1) = 0.0;
		confidence_map.at<float>(h, src.cols - 1) = 0.0;
		confidence_map.at<float>(h, src.cols - 2) = 0.0;
	}
}


void transformations::Moravec::FindConfidenceMap(cv::InputArray& original_image)
{
	cv::Mat src = original_image.getMat();

	/**/
	for (int i = 2; i < src.rows - 2; i++) {
		for (int j = 2; j < src.cols - 2; j++) {
			double s1 = 0.0;
			double s2 = 0.0;
			double s3 = 0.0;
			double s4 = 0.0;
			for (int k = 0; k < 3; k++) {
				for (int m = 0; m < 3; m++) {
					s1 = s1 + (src.at<uchar>(i - 1 + k, j - 1 + k) - src.at<uchar>(i - 2 + k, j - 1 + k))* (src.at<uchar>(i - 1 + k, j - 1 + k) - src.at<uchar>(i - 2 + k, j - 1 + k));
					s2 = s2 + (src.at<uchar>(i - 1 + k, j - 1 + k) - src.at<uchar>(i - 1 + k, j + k)) * (src.at<uchar>(i - 1 + k, j - 1 + k) - src.at<uchar>(i - 1 + k, j + k));
					s3 = s3 + (src.at<uchar>(i - 1 + k, j - 1 + k) - src.at<uchar>(i + k, j - 1 + k)) * (src.at<uchar>(i - 1 + k, j - 1 + k) - src.at<uchar>(i + k, j - 1 + k));
					s4 = s4 + (src.at<uchar>(i - 1 + k, j - 1 + k) - src.at<uchar>(i - 1 + k, j - 2 + k)) * (src.at<uchar>(i - 1 + k, j - 1 + k) - src.at<uchar>(i - 1 + k, j - 2 + k));
				}
			}
			int arr[4] = { s1,s2,s3,s4 };
			std::sort(arr, arr + 4);
			confidence_map.at<float>(i, j) = arr[0];

		}
	}


}



void transformations::Moravec::DrawFeature(cv::OutputArray& result_image)
{
	cv::Mat dst = result_image.getMat();

	for (int h = 0; h < confidence_map.rows; ++h)
	{
		for (int w = 0; w < confidence_map.cols; ++w)
		{
			if (confidence_map.at<float>(h, w) >= 15000)
			{
				cv::circle(dst, cv::Point(w, h), 3, cv::Scalar(255, 0, 0));
			}
		}
	}
}



void main()
{
	/// Load image
	cv::Mat bucks = imread("bucks.jpg", cv::IMREAD_GRAYSCALE);

	transformations::Moravec moravaec(bucks);
	moravaec.FindConfidenceMap(bucks);

	cv::Mat result_image;

	cv::cvtColor(bucks, result_image, cv::COLOR_GRAY2BGR);

	moravaec.DrawFeature(result_image);

	cv::imshow("Original Image", bucks);
	cv::imshow("Result Image", result_image);
	cv::imwrite("bucks_Moravec.bmp", result_image);
	cv::waitKey();

}