#include "opencv2/opencv.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main() {
	Mat lenna = imread("lenna.bmp", IMREAD_GRAYSCALE);
	Mat lenna_hpf = lenna.clone();
	int mask[3][3] = {{-1, -1, -1},{-1, 8, -1},{-1, -1, -1} };
	double sum;

	for (int i = 1; i < lenna.rows - 1; i++) {
		for (int j = 1; j < lenna.cols - 1; j++) {
			sum = 0;
			for (int k = 0; k < 3; k++) {
				for (int m = 0; m < 3; m++) {
					sum = sum + lenna.at<uchar>(i-1+k,j-1+m) * mask[k][m];
				}
			}
			if (sum > 255) {
				sum = 255;
			}
			else if (sum < 0) {
				sum = 0;
			}
			lenna_hpf.at<uchar>(i,j) = sum;
		}
	}

	
	cv::imwrite("lenna_hpf.bmp", lenna_hpf);
	waitKey();
}