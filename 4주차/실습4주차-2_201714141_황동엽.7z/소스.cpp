#include "opencv2/opencv.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main() {
	Mat noise = imread("salt_pepper.bmp", IMREAD_GRAYSCALE);

	for (int i = 1; i < noise.rows - 1; i++) {
		for (int j = 1; j < noise.cols - 1; j++) {
			noise.at<uchar>(i, j) = noise.at<uchar>(i-1, j) / 9 + noise.at<uchar>(i-1, j-1) / 9 + noise.at<uchar>(i, j-1) / 9
				+ noise.at<uchar>(i, j) / 9 + noise.at<uchar>(i+1, j) / 9 + noise.at<uchar>(i, j+1) / 9 +
				noise.at<uchar>(i+1, j+1) / 9 + noise.at<uchar>(i-1, j+1) / 9 + noise.at<uchar>(i+1, j-1) / 9;
		}
	}
	cv::imwrite("salt_pepper_lpf.bmp", noise);
	waitKey();
}