#include "opencv2\opencv.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main() {

	Mat cat = imread("cat.bmp");
	Mat fox = imread("tibetfox.bmp");

	Mat combine3 = 0.3 * cat + 0.7 * fox;
	cv::imwrite("dissolve_3.bmp",combine3);

	Mat combine7 = 0.7 * cat + 0.3 * fox;
	cv::imwrite("dissolve_7.bmp", combine7);

}